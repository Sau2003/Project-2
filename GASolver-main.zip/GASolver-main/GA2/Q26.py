import os, json

def execute(question: str, parameter):
    return "https://fast-api-git-main-vinilvs-projects.vercel.app/api"