import os, json

def execute(question: str, parameter):
    return "https://hub.docker.com/repository/docker/vinilmtii/nodeapi/general"